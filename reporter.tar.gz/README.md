Reporter script intaller

In order to install script on a server run setup.sh with root privilages typing following command:

sudo bash /path-to-a-script/bash.sh
